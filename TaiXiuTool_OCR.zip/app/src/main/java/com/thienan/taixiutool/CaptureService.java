package com.thienan.taixiutool;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import android.hardware.display.DisplayManager;
import androidx.annotation.Nullable;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import java.util.*;
import java.util.regex.*;

public class CaptureService extends Service {
    MediaProjection projection; ImageReader reader; VirtualDisplay display;
    Handler handler=new Handler(Looper.getMainLooper());
    TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    String last="";
    ArrayList<String> history=new ArrayList<>();

    public int onStartCommand(Intent in,int flags,int id){
        createChannel();
        startForeground(7,new Notification.Builder(this,"capture").setContentTitle("Tai Xiu Tool").setContentText("Đang đọc màn hình").setSmallIcon(android.R.drawable.ic_menu_camera).build());
        MediaProjectionManager pm=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection=pm.getMediaProjection(in.getIntExtra("resultCode",-1),(Intent)in.getParcelableExtra("data"));
        DisplayMetrics dm=getResources().getDisplayMetrics();
        int w=dm.widthPixels,h=dm.heightPixels;
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
        display=projection.createVirtualDisplay("TaiXiuOCR",w,h,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
        handler.postDelayed(captureLoop,1500);
        return START_NOT_STICKY;
    }
    Runnable captureLoop=new Runnable(){public void run(){
        if(reader!=null){
            Image im=reader.acquireLatestImage();
            if(im!=null){ Bitmap b=toBitmap(im); im.close(); if(b!=null) scan(b); }
        }
        handler.postDelayed(this,1500);
    }};
    Bitmap toBitmap(Image image){
        Image.Plane p=image.getPlanes()[0];
        java.nio.ByteBuffer buf=p.getBuffer();
        Bitmap full=Bitmap.createBitmap(image.getWidth(),image.getHeight(),Bitmap.Config.ARGB_8888);
        full.copyPixelsFromBuffer(buf);
        return full;
    }
    void scan(Bitmap b){
        InputImage input=InputImage.fromBitmap(b,0);
        recognizer.process(input).addOnSuccessListener(r -> {
            String t=r.getText().replace("\n"," ");
            String x=parse(t);
            if(x!=null && !x.equals(last)){
                last=x; history.add(x);
                while(history.size()>30) history.remove(0);
                sendBroadcast(new Intent("TAIXIU_RESULT").putExtra("history",String.join(" ",history)));
            }
        });
    }
    String parse(String t){
        String s=t.toLowerCase(Locale.US);
        if(s.matches(".*\\bt[aà]i\\b.*")) return "T";
        if(s.matches(".*\\bx[iỉ]u\\b.*")) return "X";
        Matcher m=Pattern.compile("\\b(3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18)\\b").matcher(s);
        if(m.find()){int n=Integer.parseInt(m.group(1)); return n>=11?"T":"X";}
        return null;
    }
    void createChannel(){
        if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
          .createNotificationChannel(new NotificationChannel("capture","Screen capture",NotificationManager.IMPORTANCE_LOW));
    }
    public void onDestroy(){handler.removeCallbacks(captureLoop); if(display!=null)display.release(); if(projection!=null)projection.stop(); recognizer.close(); super.onDestroy();}
    public android.os.IBinder onBind(Intent i){return null;}
}