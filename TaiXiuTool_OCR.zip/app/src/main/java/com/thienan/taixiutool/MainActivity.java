package com.thienan.taixiutool;

import android.app.*;
import android.os.*;
import android.content.*;
import android.media.projection.MediaProjectionManager;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    static final int CAPTURE_REQUEST=1001;
    TextView status,history;
    public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        status=findViewById(R.id.status); history=findViewById(R.id.history);
        findViewById(R.id.startButton).setOnClickListener(v -> requestCapture());
        findViewById(R.id.stopButton).setOnClickListener(v -> {
            stopService(new Intent(this,CaptureService.class));
            status.setText("Trạng thái: Đã dừng đọc");
        });
    }
    void requestCapture(){
        MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(),CAPTURE_REQUEST);
    }
    protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==CAPTURE_REQUEST && c==RESULT_OK){
            status.setText("Trạng thái: Đang đọc màn hình...");
            Intent i=new Intent(this,CaptureService.class);
            i.putExtra("resultCode",c); i.putExtra("data",d);
            startForegroundService(i);
        } else status.setText("Trạng thái: Chưa được cấp quyền");
    }
}